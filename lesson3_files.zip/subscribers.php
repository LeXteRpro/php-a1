<!DOCTYPE html>
<html>

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>Subscriber List</title>
<link rel="stylesheet" href="style.css" type="text/css" />
</head>

<body>
<?php
//1. connect
$conn = new PDO('mysql:host=sql.computerstudi.es;dbname=gcrfreeman', 'gcrfreeman', 'x');

//2. write sql query
$sql = "SELECT * FROM subscribers";

//3. execute the query and store the results
$result = $conn->query($sql);

//4. start our html table / grid
echo '<table><tr><th>First Name</th><th>Last Name</th><th>Email</th></tr>';

//5. loop through the results and add each row and column to the table
// <tr> creates a new row in the table
// <td> creates a new column
foreach ($result as $row) {
	echo '<tr><td>' . $row['first_name'] . '</td>
		<td>' . $row['last_name'] . '</td>
		<td>' . $row['email'] . '</td></tr>';
}

//6. close the table
echo '</table>';

//7. disconnect
$conn = null;
?>

</body>

</html>
